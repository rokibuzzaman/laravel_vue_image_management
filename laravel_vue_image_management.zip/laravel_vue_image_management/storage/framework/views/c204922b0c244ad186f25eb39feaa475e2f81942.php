<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
    </head>
    <body>
        <div class="flex-center position-ref full-height" id="app">
            <example-component></example-component>

            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-2 mb-4">
                            <a href="<?php echo e($image->original); ?>">
                                <img src="<?php echo e($image->thumbnail); ?>" class="w-100">
                            </a>
                            <form action="/images/<?php echo e($image->id); ?>" method="POST">
                                <?php echo e(method_field('delete')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button class="small btn btn-outline-danger mt-2">Delete</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH E:\project\htdocs\laravel-image-upload-vue\resources\views/welcome.blade.php ENDPATH**/ ?>