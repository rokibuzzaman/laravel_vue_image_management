<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
      <div class="row">
        <example-component></example-component>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-2 mb-4">
                            <a href="<?php echo e($image->original); ?>">
                                <img src="<?php echo e($image->thumbnail); ?>" class="w-100">
                            </a>
                            <form action="/images/<?php echo e($image->id); ?>" method="POST">
                                <?php echo e(method_field('delete')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button class="small btn btn-outline-danger mt-2">Delete</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                 <!--  <script src="<?php echo e(mix('/js/app.js')); ?>"></script> -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\htdocs\laravel-image-upload-vue\resources\views/home.blade.php ENDPATH**/ ?>