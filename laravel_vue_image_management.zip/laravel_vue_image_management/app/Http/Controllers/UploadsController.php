<?php

namespace App\Http\Controllers;

use App\ImageUpload;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

class UploadsController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }


    public function index()
    {
        $images = ImageUpload::latest()->get();

        return view('home', compact('images'));
    }

    public function store()
    {

        if(!is_dir(public_path('/images'))){
            mkdir(public_path('images'), 0777);
        }

        $images = Collection::wrap(request()->file('file'));


        $images->each(function ($image){
            $basename = Str::random();
            $original = $basename . '.' . $image->getClientOriginalExtension();
            $thumbnail = $basename . '_thumb.' . $image->getClientOriginalExtension();

            Image::make($image)
                ->fit(250, 250)
                ->save(public_path('/images/' . $thumbnail ));

            $image->move(public_path('/images'), $original);
            ImageUpload::create([
                'original' => '/images/' . $original,
                'thumbnail' => '/images/' . $thumbnail,
            ]);
            return redirect('/home');
        });


    }

    public function destroy(ImageUpload $imageUpload)
    {
        // delete the file (original and thumbnail)
        File::delete([
            public_path($imageUpload->original),
            public_path($imageUpload->thumbnail),
        ]);

        // delete from database
        $imageUpload->delete();

        // redirect
        return redirect('/home');
    }
}
